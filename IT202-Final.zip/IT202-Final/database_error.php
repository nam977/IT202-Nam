<!DOCTYPE html>

<html>
    <!-- Slide 25 -->

    <head>
        <title> My Shoe Shop </title>
        <link rel = "stylesheet" href = "main.css">
    </head>

    <body>
    <main>
        <h1> Database Error </h1>
        <p> There was an error connecting to the database </p>
        <p> Error message: <?php echo $error_message; ?> </p>
    </main>
    </body>
</html>