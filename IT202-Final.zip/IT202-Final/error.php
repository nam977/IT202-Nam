<html>
    <head>
        <title> My Shoe Store </title>
    </head>

    <body>
        <zh1> <?php echo $error; ?> </h1>
    </body>
</html>