<?php
/*
    Author: Lewis M
    UCID: nam
    Course Name: IT-202-001
    Assignment: Unit 3 Assignment
    Email: nam@njit.edu
    */
?>

<footer>
    <style>
        footer{
            position: fixed; 
            top: 90.5%; 
            left: 0; 
            right: 0; 
            bottom: 0;
            background: gray; 
            border-top: 2px solid #000;
            min-width: 200px;
        }

        #contact_info{
            font-family: Georgia, serif;
            padding: 5px;
            size: 6px
        }
    </style>

    <!-- False contact Info -->
    <div id = "contact_info">
        <label> Shipping Address: 100 West Century Road Paramus, NJ 07652 </label> <br>
        <label> Phone Number: +1 (201) 555-XXXX </label> <br>
        <label> Shipping Email: xxx432@njit.edu </label> 
    </div>
</footer>