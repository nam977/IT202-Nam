<!DOCTYPE html>

<html>
    <!-- The head section -->
    <head>
        <title> My Shoe Store </title>
        <link rel = "stylesheet" href = "main.css">
    </head>

    <!-- The body section -->

    <body>
        <main>
            <h1> Shoe Database Error </h1>
            
            <p> There was an error connecting to the shoe database </p>
            <p> Error Message: <?php echo $error_message; ?> </p>
        </main>
    </body>
</html>