<html>
    <head>
        <title> My Shoe Store </title>
    </head>

    <body>
        <h1> <?php echo $error; ?> </h1>
    </body>
</html>